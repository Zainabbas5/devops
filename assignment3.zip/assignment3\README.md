﻿# DevOps - Assignment 3 (Kubernetes)

| Task | Folder |
|---|---|
| 1 Cluster deployment and investigation | [task1-cluster](task1-cluster) |
| 2 Docker Compose to Kubernetes | [task2-compose-to-k8s](task2-compose-to-k8s) |
| 3 Scheduling, affinity, failure recovery | [task3-scheduling](task3-scheduling) |
| 4 MySQL + phpMyAdmin with PV/PVC | [task4-mysql-phpmyadmin](task4-mysql-phpmyadmin) |
| 5 ConfigMaps and Secrets | [task5-configmap-secret](task5-configmap-secret) |
| 6 Services and Ingress | [task6-services-ingress](task6-services-ingress) |
| 7 Troubleshooting challenge | [task7-troubleshooting](task7-troubleshooting) |

Environment: Fedora, Minikube (Docker driver), 2 nodes (`minikube`, `minikube-m02`), Kubernetes v1.37.0.
Report with screenshots: [REPORT.md](REPORT.md). Save screenshots in each task folder (or `screenshots/`).

## Troubleshooting issues encountered (requirement: at least two)
1. **`kubectl delete pod POD_NAME` -> `pods "POD_NAME" not found`** (Task 1, visible in screenshot 07).
   Cause: the literal placeholder was typed instead of a real pod name. Fix: run `kubectl get pods`, copy the
   real name (`nginx-app-594c6dfcf4-9d8hc`) and delete that.
2. **Pods in kube-system showed restarts (RESTARTS 3-26, "18m ago")** after the machine/cluster was restarted
   (screenshot 02). Cause: minikube containers were stopped and started again, so control-plane pods restarted.
   Fix: waited until all pods were `1/1 Running` before creating the deployment.
3. See Task 7 for four more diagnosed-and-fixed manifest issues.

