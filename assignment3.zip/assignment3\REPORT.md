# Assignment 3 - Report

**Student:** Zain Abbas  **GitHub:** https://github.com/<your-username>/devops  (private)

Each section: commands -> output/screenshot -> explanation. Details and diagrams are in each task README.

## Task 1 - Cluster Deployment and Investigation
See [task1-cluster/README.md](task1-cluster/README.md) (screenshots 01-07 included).

## Task 2 - Docker Compose to Kubernetes
See [task2-compose-to-k8s/README.md](task2-compose-to-k8s/README.md). **Add screenshots after running.**

## Task 3 - Scheduling, Affinity and Failure Recovery
See [task3-scheduling/README.md](task3-scheduling/README.md). **Add screenshots after running.**

## Task 4 - MySQL / phpMyAdmin
See [task4-mysql-phpmyadmin/README.md](task4-mysql-phpmyadmin/README.md). **Add screenshots after running.**

## Task 5 - ConfigMaps and Secrets
See [task5-configmap-secret/README.md](task5-configmap-secret/README.md). **Add screenshots after running.**

## Task 6 - Services and Ingress
See [task6-services-ingress/README.md](task6-services-ingress/README.md). **Add screenshots after running.**

## Task 7 - Troubleshooting
See [task7-troubleshooting/README.md](task7-troubleshooting/README.md). **Add screenshots after running.**

## Troubleshooting issues
See the list in [README.md](README.md).
