#!/usr/bin/env python3
"""Turns each task's output.txt into terminal-style PNG screenshots (one per command)."""
import glob
import os
import re
import sys

from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.abspath(__file__))
FONTS = [
    "/usr/share/fonts/dejavu-sans-mono-fonts/DejaVuSansMono.ttf",
    "/usr/share/fonts/dejavu/DejaVuSansMono.ttf",
    "/usr/share/fonts/liberation-mono/LiberationMono-Regular.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
]
FONT = next((f for f in FONTS if os.path.exists(f)), None)
font = ImageFont.truetype(FONT, 15) if FONT else ImageFont.load_default()
BG, FG, PROMPT, NOTE = (30, 30, 30), (220, 220, 220), (120, 220, 120), (240, 200, 90)
MAXCOL, MAXLINES, LH, PAD = 150, 55, 20, 14


def blocks(text):
    cur = []
    for line in text.splitlines():
        if (line.startswith("$ ") or line.startswith("# ")) and cur and any(l.strip() for l in cur):
            yield cur
            cur = []
        cur.append(line)
    if cur and any(l.strip() for l in cur):
        yield cur


def render(lines, path):
    shown = []
    for l in lines:
        l = l.rstrip()
        while len(l) > MAXCOL:
            shown.append(l[:MAXCOL]); l = "  " + l[MAXCOL:]
        shown.append(l)
    while shown and not shown[-1].strip():
        shown.pop()
    w = max(len(l) for l in shown) * 9 + 2 * PAD
    img = Image.new("RGB", (max(w, 700), len(shown) * LH + 2 * PAD), BG)
    d = ImageDraw.Draw(img)
    for i, l in enumerate(shown):
        color = FG
        if l.startswith("$ "):
            l = "zainabbas@fedora:~$ " + l[2:]; color = PROMPT
        elif l.startswith("# "):
            color = NOTE
        d.text((PAD, PAD + i * LH), l, font=font, fill=color)
    img.save(path)


for out in sorted(glob.glob(os.path.join(ROOT, "task*", "output.txt"))):
    tdir = os.path.dirname(out)
    sdir = os.path.join(tdir, "screenshots")
    os.makedirs(sdir, exist_ok=True)
    for old in glob.glob(os.path.join(sdir, "*.png")):
        os.remove(old)
    n = 0
    for b in blocks(open(out, encoding="utf-8", errors="replace").read()):
        head = re.sub(r"[^a-z0-9]+", "-", b[0].lower())[:40].strip("-") or "out"
        for k in range(0, len(b), MAXLINES):
            n += 1
            part = b[k:k + MAXLINES]
            if k:
                part = [b[0]] + part  # keep the command line on continuation images
            render(part, os.path.join(sdir, f"{n:02d}-{head}.png"))
    print(f"{os.path.basename(tdir)}: {n} screenshots")
