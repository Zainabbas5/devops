#!/usr/bin/env bash
# Runs Tasks 1-7 on the Fedora VM (minikube must be running with 2 nodes),
# saves every command + output to <task>/output.txt, builds REPORT.md.
# Usage:  DOCKER_USER=<dockerhub-username> bash run-all.sh [push]
# With "push" it also commits and pushes (run from inside a clone of the repo).

cd "$(dirname "$0")" || exit 1
ROOT=$(pwd)
: "${DOCKER_USER:?Set DOCKER_USER first, e.g. DOCKER_USER=myname bash run-all.sh}"

start() { OUT="$ROOT/$1/output.txt"; : > "$OUT"; cd "$ROOT/$1" || exit 1; echo; echo "=================== $1 ==================="; }
run()   { { echo "\$ $*"; bash -c "$*" 2>&1; echo; } | tee -a "$OUT"; }
note()  { echo "# $*" | tee -a "$OUT"; }

kubectl get nodes >/dev/null 2>&1 || { echo "kubectl cannot reach the cluster. Run: minikube start --driver=docker --nodes=2"; exit 1; }

############ TASK 1
start task1-cluster
kubectl get deployment nginx-app >/dev/null 2>&1 || kubectl create deployment nginx-app --image=nginx --replicas=3
kubectl rollout status deployment/nginx-app --timeout=120s
POD=$(kubectl get pods -l app=nginx-app -o jsonpath='{.items[0].metadata.name}')
run "kubectl get nodes -o wide"
run "kubectl get pods -o wide"
run "kubectl describe deployment nginx-app"
run "kubectl describe pod $POD"
run "kubectl get pods -l app=nginx-app -o custom-columns=POD:.metadata.name,POD_IP:.status.podIP,NODE:.spec.nodeName,NODE_IP:.status.hostIP,IMAGE:.spec.containers[0].image"
kubectl get svc nginx-service >/dev/null 2>&1 || kubectl expose deployment nginx-app --name=nginx-service --port=80
run "kubectl get svc"
note "Self-healing: delete $POD and watch ReplicaSet create a replacement"
run "kubectl delete pod $POD"
sleep 10
run "kubectl get pods -o wide"

############ TASK 2
start task2-compose-to-k8s
if ! command -v kompose >/dev/null; then
  mkdir -p "$HOME/.local/bin"
  curl -L https://github.com/kubernetes/kompose/releases/latest/download/kompose-linux-amd64 -o "$HOME/.local/bin/kompose" && chmod +x "$HOME/.local/bin/kompose"
  export PATH="$HOME/.local/bin:$PATH"
fi
sed -i "s/YOUR_DOCKERHUB_USERNAME/$DOCKER_USER/g" compose.yaml k8s/*.yaml
run "kompose version"
run "docker build -t $DOCKER_USER/compose-web:v1 app"
if ! docker push "$DOCKER_USER/compose-web:v1" 2>&1 | tee -a "$OUT"; then
  echo ">>> docker push failed. Run 'docker login' once, then re-run this script."; exit 1
fi
run "kompose convert -f compose.yaml -o k8s-generated/"
run "ls k8s-generated"
run "kubectl apply -f k8s/"
run "kubectl rollout status deployment/web --timeout=180s"
run "kubectl scale deployment web --replicas=3"
run "kubectl rollout status deployment/web --timeout=180s"
run "kubectl get pods,svc -o wide"
run "kubectl run curl-test --rm -i --restart=Never --image=curlimages/curl --command -- sh -c 'for i in 1 2 3 4 5 6 7 8 9 10; do curl -s web:8000; done'"
run "for i in 1 2 3 4 5; do curl -s \$(minikube ip):30800; done"

############ TASK 3
start task3-scheduling
kubectl delete deployment hello --ignore-not-found
run "kubectl apply -f hello-deployment.yaml"
kubectl rollout status deployment/hello --timeout=120s
run "kubectl describe deployment hello"
run "kubectl get pods -o wide"
run "kubectl delete -f hello-deployment.yaml"
sleep 5
run "kubectl get pods"
run "kubectl label nodes minikube-m02 disktype=ssd --overwrite"
run "kubectl get nodes --show-labels"
run "kubectl apply -f hello-deployment_updated.yaml"
kubectl rollout status deployment/hello --timeout=120s
run "kubectl get pods -o wide"
run "kubectl describe node minikube-m02 | grep -A12 -E 'Capacity|Allocated resources'"
run "kubectl apply -f hello-deployment_resources.yaml"
kubectl rollout status deployment/hello --timeout=120s
run "kubectl get pods -o wide"
run "kubectl describe pod -l app=hello | grep -B1 -A6 -E 'Limits|Requests'"
note "Node drain / failure simulation"
run "kubectl drain minikube-m02 --ignore-daemonsets --delete-emptydir-data --force"
sleep 15
run "kubectl get nodes"
run "kubectl get pods -o wide"
run "kubectl describe pod -l app=hello | grep -A4 -E 'Events|FailedScheduling'"
run "kubectl uncordon minikube-m02"
kubectl rollout status deployment/hello --timeout=120s
sleep 5
run "kubectl get pods -o wide"
kubectl delete deployment hello --ignore-not-found >/dev/null
kubectl label nodes minikube-m02 disktype- >/dev/null

############ TASK 4
start task4-mysql-phpmyadmin
run "kubectl apply -f mysql-secret.yaml -f mysql-pv-pvc.yaml"
run "kubectl get pv,pvc"
run "kubectl apply -f mysql-statefulset.yaml -f phpmyadmin.yaml"
kubectl wait --for=condition=ready pod/mysql-0 --timeout=240s
for i in $(seq 1 30); do kubectl exec mysql-0 -- mysqladmin ping -uroot -prootpass123 2>/dev/null | grep -q alive && break; sleep 5; done
run "kubectl get pods -o wide"
run "kubectl exec mysql-0 -- mysql -uroot -prootpass123 school -e \"CREATE TABLE IF NOT EXISTS students(id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(50), course VARCHAR(50)); INSERT INTO students(name,course) VALUES ('Zain','DevOps'),('Ali','Kubernetes'); SELECT * FROM students;\""
run "kubectl delete pod mysql-0"
sleep 5
kubectl wait --for=condition=ready pod/mysql-0 --timeout=240s
for i in $(seq 1 30); do kubectl exec mysql-0 -- mysqladmin ping -uroot -prootpass123 2>/dev/null | grep -q alive && break; sleep 5; done
note "After pod deletion - data must still exist:"
run "kubectl exec mysql-0 -- mysql -uroot -prootpass123 school -e 'SELECT * FROM students;'"
kubectl rollout status deployment/phpmyadmin --timeout=180s
run "kubectl get pods,svc,pv,pvc -o wide"
run "kubectl run curl-pma --rm -i --restart=Never --image=curlimages/curl --command -- curl -sI http://phpmyadmin:80"

############ TASK 5
start task5-configmap-secret
run "kubectl apply -f config-and-app.yaml"
kubectl wait --for=condition=ready pod/config-demo --timeout=120s
run "kubectl get configmap,secret"
run "kubectl get secret app-secret -o yaml"
run "kubectl exec config-demo -- env | grep -E 'APP_|DB_'"
run "kubectl exec config-demo -- ls /etc/config /etc/secret"
run "kubectl exec config-demo -- cat /etc/config/app.properties"
note "Updating ConfigMap..."
run "kubectl patch configmap app-config --type merge -p '{\"data\":{\"APP_MODE\":\"production\",\"app.properties\":\"log.level=debug\\nfeature.x=true\\n\"}}'"
sleep 80
note "Volume file (should be updated) vs env var (should still be old):"
run "kubectl exec config-demo -- cat /etc/config/app.properties"
run "kubectl exec config-demo -- env | grep APP_MODE"
run "kubectl delete pod config-demo"
run "kubectl apply -f config-and-app.yaml"
kubectl wait --for=condition=ready pod/config-demo --timeout=120s
note "After pod restart env var shows new value:"
run "kubectl exec config-demo -- env | grep APP_MODE"

############ TASK 6
start task6-services-ingress
run "minikube addons enable ingress"
kubectl wait -n ingress-nginx --for=condition=ready pod -l app.kubernetes.io/component=controller --timeout=240s
for i in 1 2 3 4 5 6; do kubectl apply -f web-app.yaml && break; sleep 15; done 2>&1 | tee -a "$OUT"
kubectl rollout status deployment/web --timeout=120s
run "kubectl get deploy,svc,ingress,endpoints -o wide"
run "kubectl run tmp-curl --rm -i --restart=Never --image=curlimages/curl --command -- curl -s http://web-clusterip"
run "curl -s http://\$(minikube ip):30090 | head -5"
run "curl -s -H 'Host: web.local' http://\$(minikube ip)/ | head -5"

############ TASK 7
start task7-troubleshooting
for n in 01-image-typo 02-service-selector 03-missing-configmap 04-unschedulable; do
  app=app${n:1:1}
  note "################ BUG $n ################"
  run "kubectl apply -f broken/$n.yaml"
  sleep 25
  run "kubectl get pods -l app=$app"
  run "kubectl describe pod -l app=$app | tail -12"
  [ "$n" = "02-service-selector" ] && { run "kubectl get endpoints app2-svc"; run "kubectl describe svc app2-svc | grep -E 'Selector|Port|Endpoints'"; }
  kubectl delete -f broken/$n.yaml --ignore-not-found >/dev/null
  note "---- applying FIX ----"
  run "kubectl apply -f fixed/$n.yaml"
  sleep 20
  run "kubectl get pods -l app=$app"
  [ "$n" = "02-service-selector" ] && run "kubectl get endpoints app2-svc"
done
kubectl delete -f fixed/ --ignore-not-found >/dev/null

############ SCREENSHOTS (rendered from the real command outputs)
cd "$ROOT" || exit 1
python3 -c "import PIL" 2>/dev/null || pip install --user pillow || sudo dnf install -y python3-pillow
python3 make_screenshots.py

############ REPORT
{
  echo "# Assignment 3 - Kubernetes Report"
  echo
  echo "**Student:** Zain Abbas  |  **GitHub:** https://github.com/Zainabbas5/devops (folder assignment3)"
  echo "**Environment:** $(. /etc/os-release; echo "$PRETTY_NAME"), minikube $(minikube version --short), $(kubectl version --client 2>/dev/null | head -1), Docker driver, 2 nodes"
  echo
  echo "Task READMEs contain explanations and diagrams; below are the real command outputs from this run."
  for t in task1-cluster task2-compose-to-k8s task3-scheduling task4-mysql-phpmyadmin task5-configmap-secret task6-services-ingress task7-troubleshooting; do
    echo; echo "---"; echo "## $t"; echo "Explanation / diagrams: [$t/README.md]($t/README.md)"; echo
    for f in "$t"/screenshots/*.png; do echo "![$f]($f)"; echo; done
    echo "<details><summary>Raw text output</summary>"; echo; echo '```'; cat "$t/output.txt"; echo '```'; echo "</details>"
  done
  echo; echo "---"; echo
  sed -n '/## Troubleshooting issues/,$p' README.md
  echo; echo "Task 1 screenshots: ![](task1-cluster/01-get-nodes.png) ![](task1-cluster/03-get-pods-wide.png) ![](task1-cluster/04-describe-deployment.png) ![](task1-cluster/07-delete-pod-self-healing.png)"
} > REPORT.md
echo "REPORT.md generated."

if [ "$1" = "push" ]; then
  git add -A && git commit -m "Assignment 3: Kubernetes tasks 1-7 with outputs and report" && git push -u origin HEAD
fi
