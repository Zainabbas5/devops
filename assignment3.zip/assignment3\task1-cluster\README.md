# Task 1 - Cluster Deployment and Investigation

## Setup commands
```bash
minikube start --driver=docker --nodes=2
kubectl get nodes -o wide
kubectl create deployment nginx-app --image=nginx --replicas=3
kubectl get pods -o wide
kubectl describe deployment nginx-app
kubectl describe pod <pod-name>
kubectl delete pod <pod-name>
kubectl get pods -w
```

## Evidence (screenshots in this folder)
| File | Shows |
|---|---|
| 01-get-nodes.png | 2-node cluster: `minikube` (control-plane) + `minikube-m02` |
| 02-kube-system-pods.png | kube-system pods, then deployment created |
| 03-get-pods-wide.png / 06-pods-and-nodes.png | 3 replicas spread over both nodes |
| 04-describe-deployment.png | describe deployment nginx-app |
| 05-get-services.png | Services (kubernetes + nginx-service ClusterIP) |
| 07-delete-pod-self-healing.png | pod deleted, new one created automatically |

## Identified values
| Item | Value |
|---|---|
| Node IP (minikube) | 192.168.49.2 |
| Node IP (minikube-m02) | 192.168.49.3 |
| Pod IPs | 10.244.1.3, 10.244.1.2 (on minikube-m02), 10.244.0.6 (on minikube) |
| Cluster IP (service nginx-service) | 10.97.104.13 (kubernetes service: 10.96.0.1) |
| Container image | nginx (latest) |
| Kubernetes version | v1.37.0, runtime containerd 2.3.4 |

(Run `kubectl describe pod <pod>` and save a screenshot as `08-describe-pod.png` - not yet captured.)

## Self-healing
Deployment -> ReplicaSet keeps `replicas: 3` as the *desired state*. When pod
`nginx-app-594c6dfcf4-9d8hc` was deleted, the ReplicaSet controller saw only 2 running pods
(actual != desired) and immediately created a new pod `nginx-app-594c6dfcf4-qmg85` (new name, new IP),
bringing the count back to 3. This is the controller reconciliation loop.

## Architecture diagram
```mermaid
flowchart TB
  user[kubectl / User] --> api
  subgraph CP["Node: minikube (control-plane) 192.168.49.2"]
    api[kube-apiserver] --- etcd[(etcd)]
    sched[scheduler]
    cm[controller-manager]
    pod3["Pod nginx 10.244.0.6"]
  end
  subgraph W["Node: minikube-m02 (worker) 192.168.49.3"]
    kubelet[kubelet + containerd]
    pod1["Pod nginx 10.244.1.3"]
    pod2["Pod nginx 10.244.1.2"]
  end
  api --> sched --> kubelet
  cm -->|Deployment -> ReplicaSet -> 3 Pods| api
  svc["Service nginx-service ClusterIP 10.97.104.13:80"] --> pod1 & pod2 & pod3
```
