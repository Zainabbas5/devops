# Task 2 - Docker Compose to Kubernetes

## 1. Install Kompose
```bash
curl -L https://github.com/kubernetes/kompose/releases/latest/download/kompose-linux-amd64 -o kompose
chmod +x kompose && sudo mv kompose /usr/local/bin/
kompose version
```

## 2. Build and publish the image (change a)
```bash
cd app
docker build -t YOUR_DOCKERHUB_USERNAME/compose-web:v1 .
docker login
docker push YOUR_DOCKERHUB_USERNAME/compose-web:v1
```

## 3. Compose changes (`compose.yaml`)
- (a) `build: .` replaced with `image: YOUR_DOCKERHUB_USERNAME/compose-web:v1`
- (b) `restart: always` on `web`
- (c) `ports: "6379:6379"` on `redis`

## 4. Convert and deploy
```bash
kompose convert -f compose.yaml -o k8s-generated/     # raw kompose output (screenshot it)
sed -i 's/YOUR_DOCKERHUB_USERNAME/<your-user>/' k8s/*.yaml
kubectl apply -f k8s/
kubectl get pods,svc -o wide
```
`k8s/` contains the kompose output after manual edits.

## 5. Generated YAML explained
| Resource | Purpose |
|---|---|
| `web-deployment.yaml` | Deployment -> ReplicaSet -> Pods running the Flask image; `restartPolicy: Always` comes from `restart: always` |
| `web-service.yaml` | Service exposing port 8000 -> pod port 5000 (NodePort 30800 added by hand) |
| `redis-deployment.yaml` | Redis pod, containerPort 6379 |
| `redis-service.yaml` | ClusterIP Service named `redis` - gives the web pods a DNS name, like the compose service name |

Manual modifications: `replicas: 3`, `REDIS_HOST` env var, NodePort type.

## 6. Scale to 3 and verify load balancing
```bash
kubectl scale deployment web --replicas=3     # or edit replicas in the YAML and re-apply
kubectl get pods -o wide
for i in $(seq 1 10); do curl -s $(minikube ip):30800; done
```
The `Served by:` field shows different pod names -> the Service load-balances across the 3 pods.
The hit counter keeps increasing because all pods share the same redis.

## 7. Docker Compose vs Kubernetes
| | Docker Compose | Kubernetes |
|---|---|---|
| Scope | single host | multi-node cluster |
| Scaling | `--scale` manual | Deployment replicas / HPA |
| Self-healing | restart policy only | ReplicaSet reschedules on other nodes |
| Load balancing | DNS round-robin | Service (kube-proxy) |
| Config | one compose file | multiple YAML objects |
| Updates | recreate | rolling update / rollback |

## Output / screenshots to add
`kompose convert`, `kubectl get pods -o wide` (3 web pods), curl loop output.
