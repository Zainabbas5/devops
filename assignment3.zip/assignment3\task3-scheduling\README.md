# Task 3 - Scheduling, Affinity and Failure Recovery

## 1. The given file `hello-deployment.yaml` explained
| Field | Value | Meaning |
|---|---|---|
| `kind` | Deployment | Controller that manages a ReplicaSet and its pods (rolling updates, self-healing) |
| `spec.replicas` | 2 | Desired number of identical pods |
| `spec.strategy` | RollingUpdate, `maxUnavailable: 100%` | Update policy: during an update all old pods may be taken down at once (fast, but brief downtime) |
| `spec.template.spec.affinity` | `podAntiAffinity` (required...) with `topologyKey: kubernetes.io/hostname` | Scheduler must NOT put two pods with label `app=hello` on the same node -> pods spread over different hosts |
| `spec.template.spec.containers` | `hello-from`, image `pbitty/hello-from:latest`, port 80 named `http` | The container that runs in each pod |
| `terminationGracePeriodSeconds` | 1 | Pods are killed almost immediately on delete |

## 2. Deploy original -> pods on different nodes
```bash
kubectl apply -f hello-deployment.yaml
kubectl describe deployment hello
kubectl get pods -o wide        # two pods, two different nodes
```

## 3. Pin both pods to one node
```bash
kubectl delete -f hello-deployment.yaml
kubectl get pods                                   # "No resources found"
kubectl get nodes
kubectl label nodes minikube-m02 disktype=ssd
kubectl get nodes --show-labels
kubectl apply -f hello-deployment_updated.yaml
kubectl get pods -o wide                           # both on minikube-m02
```
`hello-deployment_updated.yaml` = original file with the `affinity` block deleted and
`nodeSelector: disktype: ssd` added.

## 4. Node labels and resources
```bash
kubectl describe node minikube-m02        # Capacity, Allocatable, Allocated resources, Labels
kubectl top nodes                         # needs: minikube addons enable metrics-server
```

## 5. Requests and limits
```bash
kubectl apply -f hello-deployment_resources.yaml
kubectl describe pod -l app=hello | grep -A6 -i -E "limits|requests"
```
- **requests** = what the scheduler reserves (used to choose a node).
- **limits** = hard ceiling; exceeding memory limit -> OOMKilled, CPU is throttled.

## 6. Node failure / drain and recovery
```bash
kubectl drain minikube-m02 --ignore-daemonsets --delete-emptydir-data
kubectl get pods -o wide -w
kubectl get nodes                          # minikube-m02 Ready,SchedulingDisabled
kubectl uncordon minikube-m02
```
Explanation: `drain` cordons the node (no new pods) and evicts its pods. The ReplicaSet notices fewer pods
than desired and creates replacements. Because the updated deployment uses `nodeSelector disktype=ssd`
and only `minikube-m02` has the label, the new pods stay **Pending** while it is drained
(event: `0/2 nodes are available: node(s) didn't match Pod's node affinity/selector`).
After `uncordon` they are scheduled and Running again. To let them move to another node, label the other node
too (`kubectl label nodes minikube disktype=ssd`) - then recovery is automatic.

## Output / screenshots to add
describe deployment, get pods -o wide (before/after), --show-labels, describe pod resources, drain output.
