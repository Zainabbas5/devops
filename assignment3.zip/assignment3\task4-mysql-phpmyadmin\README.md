# Task 4 - MySQL (StatefulSet) + phpMyAdmin (Deployment) with PV/PVC

```bash
kubectl apply -f mysql-secret.yaml
kubectl apply -f mysql-pv-pvc.yaml
kubectl get pv,pvc                      # PVC must be Bound
kubectl apply -f mysql-statefulset.yaml
kubectl apply -f phpmyadmin.yaml
kubectl get pods -o wide
```

## Insert sample data
```bash
kubectl exec -it mysql-0 -- mysql -uroot -prootpass123 school -e "
CREATE TABLE students(id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(50), course VARCHAR(50));
INSERT INTO students(name,course) VALUES ('Zain','DevOps'),('Ali','Kubernetes');
SELECT * FROM students;"
```

## Verify persistence
```bash
kubectl delete pod mysql-0
kubectl get pods -w                      # StatefulSet recreates mysql-0
kubectl exec -it mysql-0 -- mysql -uroot -prootpass123 school -e "SELECT * FROM students;"
```
Rows are still present because `/var/lib/mysql` is on the PV, not in the container filesystem.

## Verify the app works
```bash
minikube service phpmyadmin --url        # open in browser, login root / rootpass123
```
Server `mysql`, database `school`, table `students` should be visible.

## PV - PVC architecture
```mermaid
flowchart LR
  pod["Pod mysql-0<br/>mount /var/lib/mysql"] --> pvc["PVC mysql-pvc<br/>(request 1Gi, RWO)"]
  pvc -- binds --> pv["PV mysql-pv<br/>(1Gi, hostPath /mnt/data/mysql)"]
  pv --> disk[("Disk on node minikube")]
```
- **PV**: a piece of storage in the cluster (admin side). **PVC**: a request for storage by the user.
- Kubernetes binds a PVC to a PV with matching size, accessMode and storageClassName (`manual`).
- Pod lifecycle is independent from storage: deleting the pod keeps PV data (`Retain` policy).
- Note: hostPath is node-local, so the pod is pinned to node `minikube` with a nodeSelector.
  In production use network storage / a CSI provisioner.

## Output / screenshots to add
get pv,pvc; SELECT before delete; pod recreated; SELECT after delete; phpMyAdmin in browser.
