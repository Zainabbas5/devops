# Task 5 - ConfigMaps and Secrets

```bash
kubectl apply -f config-and-app.yaml
kubectl get configmap,secret
kubectl describe configmap app-config
kubectl get secret app-secret -o yaml            # values are base64
echo -n 's3cr3t-pass' | base64
kubectl exec config-demo -- env | grep -E "APP_|DB_"       # env usage
kubectl exec config-demo -- ls /etc/config /etc/secret     # volume usage
kubectl exec config-demo -- cat /etc/config/app.properties
```

## Update ConfigMap and observe
```bash
kubectl patch configmap app-config --type merge -p '{"data":{"APP_MODE":"production","app.properties":"log.level=debug\nfeature.x=true\n"}}'
sleep 70
kubectl exec config-demo -- cat /etc/config/app.properties   # CHANGED (volume updated)
kubectl exec config-demo -- env | grep APP_MODE              # still "development" (env NOT updated)
kubectl delete pod config-demo && kubectl apply -f config-and-app.yaml   # restart -> env now "production"
```
**Observation:** files from volume-mounted ConfigMaps are refreshed automatically by kubelet
(about 1 minute delay); environment variables are fixed at container start and need a pod restart
(`kubectl rollout restart` for Deployments).

## ConfigMap vs Secret
| | ConfigMap | Secret |
|---|---|---|
| Purpose | non-sensitive config | passwords, tokens, keys |
| Storage | plain text | base64-encoded (not encryption!), can enable encryption at rest |
| Volume | files on disk | files on tmpfs (memory) |
| Access control | normal RBAC | stricter RBAC recommended |
| Size limit | 1 MiB | 1 MiB |
| Env + volume use | yes | yes |

## Output / screenshots to add
get configmap/secret, env output, file output, output after update (before/after restart).
