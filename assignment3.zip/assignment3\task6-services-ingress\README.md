# Task 6 - Services and Ingress

```bash
minikube addons enable ingress
kubectl get pods -n ingress-nginx                 # wait until controller is Running
kubectl apply -f web-app.yaml
kubectl get deploy,svc,ingress,endpoints -o wide
```

## Validation
```bash
# ClusterIP (from inside the cluster)
kubectl run tmp --rm -it --image=busybox:1.36 --restart=Never -- wget -qO- http://web-clusterip

# NodePort
curl http://$(minikube ip):30090
minikube service web-nodeport --url

# Ingress
echo "$(minikube ip) web.local" | sudo tee -a /etc/hosts
curl http://web.local
# (Docker driver on Linux: if the IP is unreachable run `minikube tunnel` in another terminal and use 127.0.0.1 web.local)
```

## Service types
| Type | Reachable from | Use |
|---|---|---|
| ClusterIP | inside cluster only | internal communication, backend for Ingress |
| NodePort | `<nodeIP>:30000-32767` | quick external access / testing |
| Ingress | HTTP(S) host/path rules via one entry point | production web routing, TLS |

## Request flow: Browser -> Ingress -> Service -> Pod
```mermaid
flowchart LR
  B[Browser<br/>http://web.local] -->|DNS /etc/hosts -> node IP| IC[Ingress Controller<br/>nginx pod]
  IC -->|matches host web.local, path /| S[Service web-clusterip<br/>ClusterIP:80]
  S -->|kube-proxy load balances<br/>via Endpoints| P1[Pod web-1]
  S --> P2[Pod web-2]
  S --> P3[Pod web-3]
```
1. Browser resolves `web.local` to the cluster IP and sends an HTTP request with `Host: web.local`.
2. The Ingress controller reads the Ingress rule and picks backend Service `web-clusterip`.
3. The Service (virtual IP) forwards to one of the pod endpoints chosen by kube-proxy.
4. The nginx pod answers; the response returns along the same path.

## Output / screenshots to add
`get svc,ingress`, curl on ClusterIP/NodePort/Ingress, browser screenshot.
