# Task 7 - Troubleshooting Challenge

Workflow for every bug: `apply broken/` -> observe -> diagnose -> `apply fixed/` -> verify.
```bash
kubectl apply -f broken/
kubectl get pods,svc,endpoints
kubectl describe pod <pod>      # Events section
kubectl logs <pod>
# fix
kubectl apply -f fixed/
kubectl get pods,endpoints
```

| # | Symptom | Diagnosis command | Root cause | Resolution |
|---|---|---|---|---|
| 1 | `ImagePullBackOff` / `ErrImagePull` | `kubectl describe pod -l app=app1` -> Events: *manifest for nginx:1.99.99-doesnotexist not found* | Non-existent image tag | Use `nginx:1.27` |
| 2 | Pods Running but `curl` via service fails; `kubectl get endpoints app2-svc` -> `<none>` | `kubectl describe svc app2-svc`, `kubectl get pods --show-labels` | Service selector `app=web-app` != pod label `app=app2`; targetPort 8080 != containerPort 80 | Fix selector to `app: app2`, targetPort 80 |
| 3 | `CreateContainerConfigError` | `kubectl describe pod -l app=app3` -> *configmap "app3-config" not found* | Referenced ConfigMap missing | Create ConfigMap `app3-config` |
| 4 | Pod `Pending` forever | `kubectl describe pod -l app=app4` -> *0/2 nodes available: Insufficient memory, didn't match node selector* | Impossible resource request and nodeSelector `gpu=true` | Reduce requests, remove nodeSelector |

## Evidence to add
For each bug: screenshot of the failing `get pods`/`describe` events, then of the working state after the fix.
Cleanup: `kubectl delete -f fixed/`
